<div class="form-group">
    <label>Nama Pengguna</label>
    <?php echo Form::text('nama', null, ['class' => 'form-control']); ?>

    <?php echo $errors->first('nama', '<span style="color: red">:message</span>'); ?>

</div>

<div class="form-group">
    <label>Username</label>
    <?php echo Form::text('username', null, ['class' => 'form-control']); ?>

    <?php echo $errors->first('username', '<span class="text-danger">:message</span>'); ?>

</div>

<div class="form-group">
    <label>Email</label>
    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

    <?php echo $errors->first('email'); ?>

</div>

<div class="form-group">
    <label>No. KP</label>
    <?php echo Form::text('ic', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label>Alamat</label>
    <?php echo Form::textarea('alamat', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label>Password</label>
    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label>Password Confirmation</label>
    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label>Role / Level</label>
    
    <?php echo Form::select('role', ['ADMIN' => 'ADMIN', 'STAFF' => 'STAFF', 'USER' => 'USER'], null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <a href="<?php echo route('users.index'); ?>" class="btn btn-secondary">
        BACK
    </a>
    <button type="submit" class="btn btn-primary float-right">SAVE</button>
</div>
