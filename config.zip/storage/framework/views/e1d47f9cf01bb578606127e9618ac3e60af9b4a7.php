<?php $__env->startSection('content'); ?>

<div class="container">
<div class="row justify-content-center">
<div class="col-md-12">
<div class="card">
<div class="card-header">Halaman Senarai Licenses Bagi Kategory <?php echo e($category->nama); ?></div>

<div class="card-body">

    <p>
        <a href="<?php echo route('licenses.create'); ?>" class="btn btn-primary">
        Tambah Licenses Baru
        </a>
    </p>

    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if( count( $category->senarai_licenses ) ): ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>CATEGORY</th>
                <th>TARIKH MULA</th>
                <th>TARIKH TAMAT</th>
                <th>PROVIDER</th>
                <th>REMARKS</th>
                <th>STATUS</th>
                <th>ACTION</th>
            </tr>
        </thead>

        <tbody>

            <?php $__currentLoopData = $category->senarai_licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->category->nama); ?></td>
                <td><?php echo e($item->tarikh_mula); ?></td>
                <td><?php echo e($item->tarikh_tamat); ?></td>
                <td><?php echo e($item->provider); ?></td>
                <td><?php echo e($item->remarks); ?></td>
                <td><?php echo e($item->status); ?></td>
                <td>
                    <a class="btn btn-sm btn-info" href="<?php echo e(route('licenses.edit', ['id' => $item->id ])); ?>">EDIT</a>

                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal-delete-<?php echo e($item->id); ?>">
                        DELETE
                    </button>

                    <!-- Modal -->
                    <form method="POST" action="<?php echo e(route('licenses.destroy', ['id' => $item->id ])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>

                    <div class="modal fade" id="modal-delete-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            Adakah anda bersetuju untuk menghapuskan data berikut:

                            <p>ID: <?php echo e($item->id); ?></p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Confirm</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    </form>

                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>


    </table>

    <?php endif; ?>

</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>