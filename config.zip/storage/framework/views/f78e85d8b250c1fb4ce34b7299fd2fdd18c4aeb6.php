<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <?php echo $__env->yieldContent('content_header'); ?>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->
    <?php echo $__env->yieldContent('stat_box'); ?>
    <!-- /.row -->
    <!-- Main row -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.row (main row) -->

  </section>
  <!-- /.content -->
</div>
