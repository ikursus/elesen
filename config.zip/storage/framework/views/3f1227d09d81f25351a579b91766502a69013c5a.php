<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Maklumat Kategori</div>

                <div class="card-body">

                    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
<form method="POST" action="<?php echo e(route('categories.store')); ?>">
<?php echo csrf_field(); ?>

    <div class="form-group">
        <label>KOD KATEGORI</label>
        <input class="form-control" type="text" name="kod">
    </div>

    <div class="form-group">
        <label>NAMA KATEGORI</label>
        <input class="form-control" type="text" name="nama">
    </div>

    <div class="form-group">
        <a href="<?php echo route('categories.index'); ?>" class="btn btn-secondary">
            BACK
        </a>
        <button type="submit" class="btn btn-primary float-right">SAVE</button>
    </div>

</form>

</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>