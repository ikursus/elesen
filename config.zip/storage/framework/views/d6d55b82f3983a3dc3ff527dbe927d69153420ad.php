<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Maklumat Lesen</div>

                <div class="card-body">

                    <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<form method="POST" action="<?php echo e(route('licenses.store')); ?>">
<?php echo csrf_field(); ?>

    <div class="form-group">
        <label>KATEGORI</label>
        <select name="category_id" class="form-control">

            <?php $__currentLoopData = $senarai_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
    </div>

    <div class="form-group">
        <label>TARIKH MULA</label>
        <input class="form-control" type="date" name="tarikh_mula" value="<?php echo e(old('tarikh_mula')); ?>">
    </div>

    <div class="form-group">
        <label>TARIKH TAMAT</label>
        <input class="form-control" type="date" name="tarikh_tamat" value="<?php echo e(old('tarikh_tamat')); ?>">
    </div>

    <div class="form-group">
        <label>REMARKS</label>
        <textarea class="form-control" name="remarks"><?php echo e(old('remarks')); ?></textarea>
    </div>

    <div class="form-group">
        <label>PROVIDER</label>
        <input class="form-control" type="text" name="provider" value="<?php echo e(old('provider')); ?>">
    </div>

    <div class="form-group">
        <label>STATUS</label>
        <select name="status" class="form-control">

            <?php $__currentLoopData = $senarai_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item['status']); ?>"><?php echo e($item['status']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
    </div>

    <div class="form-group">
        <a href="<?php echo route('licenses.index'); ?>" class="btn btn-secondary">
            BACK
        </a>
        <button type="submit" class="btn btn-primary float-right">SAVE</button>
    </div>

</form>

</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>