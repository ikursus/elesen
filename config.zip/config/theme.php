<?php

return [

    'name' => env('APP_THEME', 'adminlte'),

];
